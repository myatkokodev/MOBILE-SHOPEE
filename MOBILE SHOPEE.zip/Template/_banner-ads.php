            <!--Banner Ads-->
            <section class="banner_ads">
                     <div class="container py-5 text-center">
                         <img src="./assets/banner1-cr-500x150.jpg" alt="banner1" class="img-fluid">
                         <img src="./assets/banner2-cr-500x150.jpg" alt="banner2" class="img-fluid">
                     </div>
                 </section>
            <!--End Banner Ads-->