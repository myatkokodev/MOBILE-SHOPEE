<?php
    //include header.php file
    include("header.php");
?>

<?php 

    /* include products */
    include("Template/_products.php");
    /* include products */
    
    /*include top sale area*/
    include("Template/_top-sale.php");  
    /*include top sale area*/

?>


<?php
    //include footer.php file
    include("footer.php");     
?>