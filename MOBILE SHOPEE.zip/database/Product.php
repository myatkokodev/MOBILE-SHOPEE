<?php

//Use to fetch product data

class Product{
    public $db = null;

    public function __construct(DBcontroller $db){
        if(!isset($db->con)) return null;
        $this->db = $db;
    }


    //fetch product data using getData method
    public function getData($table='product'){
        $result = $this->db->con->query("SELECT * FROM {$table}");
        //$result = $this->db->con->query(query: "SELECT * FROM {$table}");

        $resultArray = array();

        //fetch  product data one by one
        while($item = mysqli_fetch_array($result,MYSQLI_ASSOC)){
            $resultArray[] = $item;
        }

        return $resultArray;
    }

    //get product using item_id

    public function getProducts($item_id = null,$table = "product"){
        if(isset($item_id)){
            $result = $this->db->con->query("SELECT * FROM {$table} WHERE item_id = {$item_id}");

            $resultArray = array();

            //fetch product data one by one

            while($item = mysqli_fetch_array($result,MYSQLI_ASSOC)){
                $resultArray[] = $item;
            }

            return $resultArray;
        }

    }

}